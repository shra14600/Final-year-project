
<?php include'includes/common.php'; 
if(isset($_SESSION['email_id'])){
    header('location:home.php');
}

?>

<!DOCTYPE html>
<html>
<head>
<title> Welcome | TECHZONE </title>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<meta name="description" content="">
<meta name="author" content="">

<link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" type="text/css">
<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js" type="text/javascript">
</script>
<script src="js/bootstrap.min.js" type="text/javascript">
</script>

<link rel="stylesheet"  type="text/css" href="css/style.css">
</head>

<body>




   <?php include 'includes/header.php'; ?>



<div class="rash3" id="content">
<div class="jumbotron jumbotron-fluid">
<div class="container moving">
<h1>

    Learn HTML
</h1>

<p class="lead">  Hypertext Markup Language (HTML) is the standard markup language for documents designed to be displayed in a web browser.  </p> 
<p class="lead">
<a href="html.php" class="btn btn-warning btn-lg" role="button"><span class="glyphicon glyphicon-hand-right"></span> Learn Now </a>
</p>
<br>
<hr>


</div>

</div>



<div class="jumbotron jumbotron-fluid">
<div class="container moving">
<h1>

    Learn CSS
</h1>

<p class="lead">  Cascading Style Sheets (CSS) is a style sheet language used for describing the presentation of a document written in a markup language like HTML.</p> 
<p class="lead">
<a href="css.php" class="btn btn-danger btn-lg" role="button"> <span class="glyphicon glyphicon-hand-right"></span>  Learn Now </a>
</p>
<br>
<hr>

</div>

</div>


<div class="jumbotron jumbotron-fluid">
<div class="container moving">
<h1>

    Learn Bootstrap
</h1>

<p class="lead"> Bootstrap is HTML,CSS and JS framework for developing responsive mobile first project on the web. </p> 
<p class="lead">
<a href="bootstrap.php" class="btn btn-primary btn-lg" role="button"> <span class="glyphicon glyphicon-hand-right"></span>  Learn Now </a>
</p>
<br>
<hr>

</div>

</div>


<div class="jumbotron jumbotron-fluid">
<div class="container moving">
<h1>

    Learn MySQL
</h1>

<p class="lead">MySQL is an open-source relational database management system (RDBMS). MySQL is free and open-source software under the terms of the GNU General Public License.</p> 
<p class="lead">
<a href="mysql.php" class="btn btn-success btn-lg" role="button"><span class="glyphicon glyphicon-hand-right"></span> Learn Now </a>
</p>
<br>
<hr>

</div>

</div>



<div class="jumbotron jumbotron-fluid">
<div class="container moving">
<h1>

    Learn PHP
</h1>

<p class="lead"> PHP: Hypertext Preprocessor (or simply PHP) is a general-purpose programming language originally designed for web development.          </p> 
<p class="lead">
<a href="php.php" class="btn btn-info btn-lg" role="button"><span class="glyphicon glyphicon-hand-right"></span> Learn Now </a>
</p>
<br>
<hr>

</div>

</div>

</div>
    
    <?php include 'includes/footer.php'; ?>

</body>

</html>