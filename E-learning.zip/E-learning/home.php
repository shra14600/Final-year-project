<?php
include'includes/common.php';
 ?>


<!DOCTYPE html>
<html>
<head>
<title> Welcome | TECHZONE </title>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<meta name="description" content="">
<meta name="author" content="">

<link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" type="text/css">
<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js" type="text/javascript">
</script>
<script src="js/bootstrap.min.js" type="text/javascript">
</script>

<link rel="stylesheet"  type="text/css" href="css/style.css">
</head>

<body>
    
   <?php 
         include 'includes/header.php' ;
         
         include 'includes/check-if-enrolled.php';
         
   ?>
    
<div id="content">
    <div class="container-fluid">
        
        
        <div class="row">
            <div class="col-sm-12">
            
            <div class="jumbotron jumbotron-fluid jumbo">
  
            
                 <h1>LEARN HTML </h1>
                <p class="lead">  Hypertext Markup Language (HTML) is the standard markup language for documents designed to be displayed in a web browser.  </p>
               
            <?php if (!isset($_SESSION['email_id'])) { ?>                               
<p><a href="#" role="button" class="btn btn-primary btn-lg"> Enroll Now    </a></p>                                
 <?php                            
 } else {                                
     //We have created a function to check whether this particular product is added to cart or not.                                 
     if (check_if_added_to_cart(1)) { 
//This is same as if(check_if_added_to_cart != 0)                                     
echo '<a href="html.php" class="btn btn-warning btn-lg" >Learn Now</a>';                                
} else {                                    
    ?>                                    
<a href="includes/cart-add.php?id=1" name="add" value="add" class="btn btn-lg btn-primary">Enroll Now</a>                                   
  <?php                                
  }                            
  }                             
  ?>
            
            </div>
            
                <div class="jumbotron jumbotron-fluid jumbo">
  
            
                 <h1>LEARN CSS </h1>
                <p class="lead">  Cascading Style Sheets (CSS) is a style sheet language used for describing the presentation of a document written in a markup language like HTML.  </p>
                   
            <?php if (!isset($_SESSION['email_id'])) { ?>                               
<p><a href="#" role="button" class="btn btn-primary btn-lg"> Enroll Now    </a></p>                                
 <?php                            
 } else {                                
     //We have created a function to check whether this particular product is added to cart or not.                                 
     if (check_if_added_to_cart(2)) { 
//This is same as if(check_if_added_to_cart != 0)                                     
echo '<a href="css.php" class="btn btn-warning btn-lg" >Learn Now</a>';                                
} else {                                    
    ?>                                    
<a href="includes/cart-add.php?id=2" name="add" value="add" class="btn btn-primary btn-lg">Enroll Now</a>                                   
  <?php                                
  }                            
  }                             
  ?>
            
            
              
            </div>
            
            
                
                <div class="jumbotron jumbotron-fluid jumbo">
  
            
                 <h1>LEARN Bootstrap </h1>
                <p class="lead"> Bootstrap is HTML,CSS and JS framework for developing responsive mobile first project on the web. </p>
                   
            <?php if (!isset($_SESSION['email_id'])) { ?>                               
<p><a href="#" role="button" class="btn btn-primary btn-lg"> Enroll Now    </a></p>                                
 <?php                            
 } else {                                
     //We have created a function to check whether this particular product is added to cart or not.                                 
     if (check_if_added_to_cart(3)) { 
//This is same as if(check_if_added_to_cart != 0)                                     
echo '<a href="bootstrap.php" class="btn btn-warning btn-lg" >Learn Now</a>';                                
} else {                                    
    ?>                                    
<a href="includes/cart-add.php?id=3" name="add" value="add" class="btn btn-lg btn-primary">Enroll Now</a>                                   
  <?php                                
  }                            
  }                             
  ?>
                </div>
                
                
                <div class="jumbotron jumbotron-fluid jumbo">
  
            
                 <h1>LEARN MySQL </h1>
                <p class="lead"> MySQL is an open-source relational database management system (RDBMS). MySQL is free and open-source software under the terms of the GNU General Public License. </p>
                   
            <?php if (!isset($_SESSION['email_id'])) { ?>                               
<p><a href="#" role="button" class="btn btn-primary btn-lg"> Enroll Now    </a></p>                                
 <?php                            
 } else {                                
     //We have created a function to check whether this particular product is added to cart or not.                                 
     if (check_if_added_to_cart(4)) { 
//This is same as if(check_if_added_to_cart != 0)                                     
echo '<a href="mysql.php" class="btn btn-warning btn-lg" >Learn Now</a>';                                
} else {                                    
    ?>                                    
<a href="includes/cart-add.php?id=4" name="add" value="add" class="btn btn-lg btn-primary">Enroll Now</a>                                   
  <?php                                
  }                            
  }                             
  ?>
            
            
            
            
            </div>
            
            
                
                <div class="jumbotron jumbotron-fluid jumbo">
  
            
                 <h1>LEARN PHP</h1>
                <p class="lead">  PHP: Hypertext Preprocessor (or simply PHP) is a general-purpose programming language originally designed for web development. </p>
                   
            <?php if (!isset($_SESSION['email_id'])) { ?>                               
<p><a href="#" role="button" class="btn btn-primary btn-lg"> Enroll Now    </a></p>                                
 <?php                            
 } else {                                
     //We have created a function to check whether this particular product is added to cart or not.                                 
     if (check_if_added_to_cart(5)) { 
//This is same as if(check_if_added_to_cart != 0)                                     
echo '<a href="php.php" class="btn btn-warning btn-lg" >Learn Now</a>';                                
} else {                                    
    ?>                                    
<a href="includes/cart-add.php?id=5" name="add" value="add" class="btn btn-lg btn-primary">Enroll Now</a>                                   
  <?php                                
  }                            
  }                             
  ?>
            
            
            
            </div>
            
            
            
            
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
            </div>
        </div>
        
     </div>
 
     </div>
   
    <?php include'includes/footer.php'; ?>
</body>
</html>
