<?php

$con=mysqli_connect("localhost","root","","elearn") or die(mysqli_error($con));
session_start();

error_reporting(0);
?>