


<div class="container-fluid rash">
<div class="container">
<ul class="nav navbar-nav">
    <?php 
    if(!isset($_SESSION['email_id'])) {
        ?>
<li> <a href="index.php"> <img src="img/lion.jpg" class="img-thumbnail rash1" alt=""> </a>  </li>
<li> <h1> TECHZONE </h1> </li>
<?php
    }
  else {
    ?>
<li> <a href="home.php"> <img src="img/lion.jpg" class="img-thumbnail rash1" alt=""> </a>  </li>
<li> <h1> TECHZONE </h1> </li>
<?php 
  }
  ?>

</ul>


</div>
</div>




<nav class="navbar navbar-default">
<div class="container">
<div class="navbar-header">

<button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
<span class="icon-bar"> </span>
<span class="icon-bar"> </span>
<span class="icon-bar"> </span>
</button>
 <?php 
    if(!isset($_SESSION['email_id'])) {
        ?>
<a href="index.php" class="navbar-brand glyphicon glyphicon-home"> Home </a>
<?php
    }
  else {
    ?>
<a href="home.php" class="navbar-brand glyphicon glyphicon-home"> Home  </a>

<?php
  }
  ?>

</div>

<div class="collapse navbar-collapse" id="myNavbar">
<ul class="nav navbar-nav navbar-right">
    
     <?php 
    if(!isset($_SESSION['email_id'])) {
        ?>
<li>  <a href="signup.php"><span class="glyphicon glyphicon-user text-color"> </span>  Sign Up</a> </li> 
<li> <a href="login.php"> <span class="glyphicon glyphicon-log-in text-color"> </span> Login </a> </li>

<li> <a href="contact.php"> <span class="glyphicon glyphicon-phone text-color"> </span> Contact Us </a> </li>


<?php
    }
  else {
    ?>
<li> <a href="cart.php"><span class="glyphicon glyphicon-user"> </span>  My Courses</a> </li>
<li> <a href="settings.php"> <span class="glyphicon glyphicon-cog"> </span> Settings</a> </li>
<li> <a href="includes/logout.php"> <span class="glyphicon glyphicon-log-out"> </span> Logout</a> </li>

<?php
  } ?>
</ul>
</div>

</div>
</nav>



