


<footer>

<div class="container-fluid">
<div class="container moving">
<br>
<br>
<br>
<div class="row">

<div class="col-xs-12 col-sm-4">

<h3> Programming Languages </h3>


<p><a href="html.php" class="text-color">  <span class="glyphicon glyphicon-chevron-right"> </span> Learn HTML </a></p>
<p><a href="css.php" class="text-color">  <span class="glyphicon glyphicon-chevron-right"> </span> Learn CSS </a> </p>
<p><a href="bootstrap.php" class="text-color">  <span class="glyphicon glyphicon-chevron-right"> </span> Learn Bootstrap </a> </p>
<p><a href="mysql.php" class="text-color"> <span class="glyphicon glyphicon-chevron-right"> </span> Learn MySQL </a></p>
<p><a href="php.php" class="text-color"> <span class="glyphicon glyphicon-chevron-right"> </span> Learn PHP </a>
</p>
</div>

<div class="col-xs-12 col-sm-4">

<h3> My Account </h3>
<?php 
    if(!isset($_SESSION['email_id'])) {
        ?>
<p >
<a href="signup.php" class="text-color"><span class="glyphicon glyphicon-chevron-right"> </span>  Sign up </a>
</p>
<p >
<a href="login.php" class="text-color"> <span class="glyphicon glyphicon-chevron-right"> </span> Login </a>
</p>



<?php
    }
  else {
    ?>
<p >
<a href="cart.php" class="text-color"><span class="glyphicon glyphicon-chevron-right"> </span>  My Courses </a>
</p>
<p >
<a href="settings.php" class="text-color"> <span class="glyphicon glyphicon-chevron-right"> </span> Settings </a>
</p>

<?php 
  }
  ?>
</div>

<div class="col-xs-12 col-sm-4">
<h3> Contact US </h3>

<p > <span class="glyphicon glyphicon-chevron-right"> </span> Contact: +917898709090 </p>
</div>

 </div>
</div>
</div>

</footer>