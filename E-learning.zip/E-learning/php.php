<?php include'includes/common.php'; 
if(!isset($_SESSION['email_id'])){
    header('location:login.php');
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
  <title>BLOGTECH | HTML</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
  <link rel="stylesheet" href="css/style.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
  
 
</head>
<body>

<?php include'includes/header.php'; ?>




<div class="content marg1">
<div class="container-fluid">
  <div class="row content">
    <div class="col-sm-2 sidenav">
      <h4>Rashid's Blog</h4>
      <ul class="nav nav-pills nav-stacked ">
	  <li> <button class="btn btn-danger btn-block focus"> <h4>PHP</h4></button> </li>
        <li class="active"><a  data-toggle="tab" href="#section1">INTRODUCTION</a></li>
        <li><a data-toggle="tab" href="#section2">Text Editor</a></li>
		 <li><a  data-toggle="tab" href="#section3">Attributes</a></li>
        <li><a data-toggle="tab" href="#section4">Box Model</a></li>
        <li><a data-toggle="tab" href="#section5">Colors</a></li>
		<li><a data-toggle="tab" href="#section6">Css External</a></li>
		<li><a data-toggle="tab" href="#section7">Css Inline</a></li>
		<li><a data-toggle="tab" href="#section8"> Fonts </a></li>
		<li><a data-toggle="tab" href="#section9"> Forms</a></li>
		<li><a data-toggle="tab" href="#section10"> Lists</a></li>
		<li><a data-toggle="tab" href="#section11">Creating layout</a></li>
		<li><a data-toggle="tab" href="#section12">Images</a></li>
		<li><a data-toggle="tab" href="#section13">Tables</a></li>
		<li><a data-toggle="tab" href="#section14">Navigation</a></li>
		<li><a data-toggle="tab" href="#section15">Miscellaneous</a></li>
      </ul><br><br>
      <div class="input-group">
        <input type="text" class="form-control" placeholder="Search Blog..">
        <span class="input-group-btn">
          <button class="btn btn-default" type="button">
            <span class="glyphicon glyphicon-search"></span>
          </button>
        </span>
      </div>
    </div>

<div class="tab-content">
<div id="section1" class="tab-pane fade in active">
 <div class="col-sm-8">
       <h4><small>RECENT POSTS</small></h4>
      <hr>
      <h1> PHP</h1>
      <h5><span class="glyphicon glyphicon-time"></span> Posted on July 12, 2019.</h5>
      <h5><span class="label label-danger">Web Development</span></h5><br>
	 
	 
	 
	 
	 
	 
</div>
</div>
<!--INTRODUCTION ENDS -->


</div>


 <div class="col-sm-2 sidenav">
      <div class="well">
        <p>ADS</p>
      </div>
      <div class="well">
        <p>ADS</p>
      </div>
    </div>
</div>
</div>
</div>

    <?php include'includes/footer.php'; ?>
</div>


</body>
</html>


