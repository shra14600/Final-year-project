<?php include'includes/common.php'; 
if(!isset($_SESSION['email_id'])){
    header('location:login.php');
}

?>



<!DOCTYPE html>
<html lang="en">
<head>
  <title>BLOGTECH | HTML</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
  <link rel="stylesheet" href="css/style.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
  
 
</head>
<body>

<?php include'includes/header.php'; ?>








<div class="content marg1">
<div class="container-fluid">
  <div class="row content">
    <div class="col-sm-2 sidenav sidenav-height">
      <h4>Rashid's Blog</h4>
      <ul class="nav nav-pills nav-stacked ">
	  <li> <button class="btn btn-danger btn-block focus"> <h4>HTML </h4></button> </li>
        <li class="active"><a  data-toggle="tab" href="#section1">INTRODUCTION</a></li>
        <li><a data-toggle="tab" href="#section2">Text Editor</a></li>
		 <li><a data-toggle="tab" href="#section3">Page Structure</a></li>
        <li><a data-toggle="tab" href="#section4">Tags and Elements</a></li>
		 <li><a data-toggle="tab" href="#section5">Text Formatting</a></li>
        <li><a data-toggle="tab" href="#section6">Attributes</a></li>
		<li><a data-toggle="tab" href="#section7">Hyperlinks</a></li>
		<li><a data-toggle="tab" href="#section8">Forms </a></li>
		<li><a data-toggle="tab" href="#section9">Image</a></li>
		<li><a data-toggle="tab" href="#section10">List</a></li>
		<li><a data-toggle="tab" href="#section11">Table</a></li>
      </ul><br>
      <div class="input-group">
        <input type="text" class="form-control" placeholder="Search Blog..">
        <span class="input-group-btn">
          <button class="btn btn-default" type="button">
            <span class="glyphicon glyphicon-search"></span>
          </button>
        </span>
      </div>
    </div>

<div class="tab-content">
<div id="section1" class="tab-pane fade in active">
    <div class="col-sm-8">
      <h4><small>RECENT POSTS</small></h4>
      <hr>
      <h1>HTML</h1>
      <h5><span class="glyphicon glyphicon-time"></span> Posted on July 12, 2019.</h5>
      <h5><span class="label label-danger">Web Development</span></h5><br>
	  
	  
	  <h3> INTRODUCTION : </h3>
      <p>Hypertext Markup Language (HTML) is the standard markup language for documents designed to be displayed in a web browser. It can be assisted by technologies such as Cascading Style Sheets (CSS) and scripting languages such as JavaScript.HTML is a markup language that web browsers use to interpret and compose text, images, and other material into visual or audible web pages. Default characteristics for every item of HTML markup are defined in the browser, and these characteristics can be altered or enhanced by the web page designer's additional use of CSS.
      <br>
	  <br>
	  HTML elements are the building blocks of HTML pages. With HTML constructs, images and other objects such as interactive forms may be embedded into the rendered page. HTML provides a means to create structured documents by denoting structural semantics for text such as headings, paragraphs, lists, links, quotes and other items. HTML elements are delineated by tags, written using angle brackets. Tags such as <code> &lt;img&gt; </code> and <code> &lt;input&gt; </code> </em> directly introduce content into the page. Other tags such as <code> &lt;p&gt; </code> surround and provide information about document text and may include other tags as sub-elements. Browsers do not display the HTML tags, but use them to interpret the content of the page.</p>
	 <br>
	 <br>
	 
	 
	 
	 <h3> HISTORY : </h3>
	 <p>
	 
	 In 1980, physicist Tim Berners-Lee, a contractor at CERN, proposed and prototyped ENQUIRE, a system for CERN researchers to use and share documents. In 1989, Berners-Lee wrote a memo proposing an Internet-based hypertext system.Berners-Lee specified HTML and wrote the browser and server software in late 1990. That year, Berners-Lee and CERN data systems engineer Robert Cailliau collaborated on a joint request for funding, but the project was not formally adopted by CERN. In his personal notes from 1990 he listed "some of the many areas in which hypertext is used" and put an encyclopedia first.<br>
	 <br>

    The first publicly available description of HTML was a document called "HTML Tags", first mentioned on the Internet by Tim Berners-Lee in late 1991.It describes 18 elements comprising the initial, relatively simple design of HTML. Except for the hyperlink tag, these were strongly influenced by SGMLguid, an in-house Standard Generalized Markup Language (SGML)-based documentation format at CERN. Eleven of these elements still exist in HTML 4.
	<br>
	<br>
	 
	 Further development under the auspices of the IETF was stalled by competing interests. Since 1996, the HTML specifications have been maintained, with input from commercial software vendors, by the World Wide Web Consortium (W3C).However, in 2000, HTML also became an international standard (ISO/IEC 15445:2000). HTML 4.01 was published in late 1999, with further errata published through 2001. In 2004, development began on HTML5 in the Web Hypertext Application Technology Working Group (WHATWG), which became a joint deliverable with the W3C in 2008, and completed and standardized on 28 October 2014.
	 
	 </p>
	 
      <br>
	  <br>
      <hr>
	  </div>
	  
</div>	 
	 <!-- Introduction completed -->
  
  <div id="section2" class="tab-pane fade">
    <div class="col-sm-8">
	<h4><small>RECENT POSTS</small></h4>
      <hr>
      <h1>HTML</h1>
      <h5><span class="glyphicon glyphicon-time"></span> Posted on July 12, 2019.</h5>
      <h5><span class="label label-danger">Web Development</span></h5><br>

<h3> Text Editor </h3>
<p>Whether you’re a tech-savvy web design genius or a beginner, you’ve probably realized the usefulness of having a basic familiarity with HTML. As one of the most fundamental languages for website creation, you can’t go wrong with a little HTML knowledge in your back pocket.<br>
<br>
No matter if you know a little or a lot, there’s a tool out there that can help take your HTML skills to the next level … or at least make sure your code is correct.<br>
<br>
That tool? An HTML editor.<br>
<br>
Remember: With these editors, you’ll want to have more than a basic understanding of HTML. These tools can help you fix mistakes, but they can’t write your code for you.<br>
You can use Notepad too.</p>
<br>
<br>
<p> Download any one of the following : </p>

<ul class="nav" style="diplay:block;">
<li><a href="#"> <span class="glyphicon glyphicon-download"> </span> CoffeeCup HTML Editor</a> </li>

<li><a href="#"> <span class="glyphicon glyphicon-download"> </span> Komodo Edits </a> </li>

<li><a href="#"> <span class="glyphicon glyphicon-download"> </span> NetBeans </a> </li>

<li><a href="#"> <span class="glyphicon glyphicon-download"> </span> Notepad++ </a> </li>

<li><a href="#"> <span class="glyphicon glyphicon-download"> </span> Visual Studio Code </a> </li>
</ul>

<br>
<br>
<p class="lead"> Install it and write some html code.</p> 

<p class="lead"> <b style="color:red;"> NOTE: </b> Always save the file with .htm or .html as file extension.<br> </p>
<p class="lead"> Example:  file_name.htm or file_name.html </p>

</div>
</div>
<!--Text Editor -->



<div id="section3" class="tab-pane fade">
    <div class="col-sm-8">
      <h4><small>RECENT POSTS</small></h4>
      <hr>
      <h1>HTML</h1>
      <h5><span class="glyphicon glyphicon-time"></span> Posted on July 12, 2019.</h5>
      <h5><span class="label label-danger">Web Development</span></h5><br>
	  
	  
	  <h3> Basic HTML Web Page Structure:</h3>
	  <p>A web page constructed using HTML has a basic and essential structure. The page always begins with the start tag of the html element (<code>&lt;html&gt;</code>) and always terminates with the end tag of the html element (<code>&lt;/html&gt;</code>) as follows: </p> <br>
	  <p class="text-center lead"> Example 1: </p>
	 <textarea  id="myInput" class="form-control">
	  <html> Web Page.. </html>
	  </textarea><br>
	 <button class="btn btn-warning" onclick="myFunction()">Copy text </button>
	 <br>
<br>
<p>The html element basically tells your computer that this is an HTML document. All other element tags are 'nested' within the start and end html tags. The web page is then further subdivided into two main sections which are the 'head' and the 'body'. <br>
<br>

The head section begins with the <code>&lt;head&gt;</code> start tag and terminates with the <code>&lt;/head&gt;</code> end tag. Immediately following this comes the <code>&lt;body&gt;</code> start tag and just before the html end tag comes the <code>&lt;/body&gt;</code> end tag. <br>
<br>

There is only one set of <code>&lt;html&gt;</code>...<code>&lt;/html&gt;</code> tags, one set of <code>&lt;head&gt;</code>...<code>&lt;/head&gt;</code> tags and one set of <code>&lt;body&gt;</code>...<code>&lt;/body&gt;</code>tags. This basic HTML web page structure can be illustrated by the following example:
</p>

<p class="text-center lead"> Example 2: </p>
	 <textarea id="myInput1" class="form-control minih">
	<html> 
	    <head> 
	     </head>
	        <body>
	     </body> 
	</html>
	
	</textarea> <br>
	 <button class="btn btn-warning" onclick="myFunction1()"> Copy Text </button>
	  
<br>
<br>
<h3> Adding Title To Our Homepage </h3>

<p class="text-center lead"> Example 3: </p>

	<textarea class="form-control minih" id="myInput2"> 
	<html> 
	       <head>  
		      <title>  My Homepage </title>
	       </head> 
	   <body>
	   </body>
	  
	</html>
</textarea>
	<br>
<button class="btn btn-warning" onclick="myFunction2()">Copy text</button>
<br>
<br>
<h3> Adding Content To Our Web Page </h3>


<p>Now to add some content to your web page all you have to do is type some text in between the <body>...</body> tags. So let's, for example, put the words 'HELLO WORLD!' on your web page. </p>

<p class="text-center lead"> Example 4: </p>
	
	 <textarea id="myInput3" class="form-control minih">
	<html> 
	    <head> 
		     <title> Homepage </title>
	     </head>
	        <body>
			   <p> Hello World! </p>
	     </body> 
	</html>
	
	</textarea> <br>
	 <button class="btn btn-warning" onclick="myFunction3()"> Copy Text </button>

<br>
<br>
	
	
<hr>


</div>
</div>

<div id="section4" class="tab-pane fade">
    <div class="col-sm-8">
      <h4><small>RECENT POSTS</small></h4>
      <hr>
      <h1>HTML</h1>
      <h5><span class="glyphicon glyphicon-time"></span> Posted on July 12, 2019.</h5>
      <h5><span class="label label-danger">Web Development</span></h5><br>
	  
	  
	  <h3> HTML Tags </h3>
	  <p> HTML Tags are hidden keywords within a webpage that define how the browser must format and display the content.Most of these tags have two parts, opening tag or start tag and closing tag or end tag. </p> 	  
	  <br>
	 <h3> HTML Elements</h3>
	 <p> An HTML element usually consists of a start tag and an end tag, with the content inserted in between:</p>
	 <br>
	  <div class="thumbnail">
	  
	  <img src="img/ss.png" class="img-responsive">
    </div>
<br>
<br>
<h4> Some Tags: </h4>
<p> <code> &lt;p&gt; </code>  (paragraph Tag) </p>
<p> <code> &lt;h1&gt; - &lt;h6&gt; </code>(Heading Tag) </p>
<p> <code> &lt;b&gt;  </code> (bold Tag) </p>
<p> <code> &lt;br&gt;  </code>(br or line break Tag) also called empty tag because it does not have end tag/closing tag. </p>
  <br>
  <p class="text-center lead"> Example </p>
<textarea id="myInput4" class="form-control minih">

<html>
<head>

<title> Batman </title>
</head>
<body>
<h1> BATMAN - THE DARK NIGHT </h1>
<p> <b> BATMAN </b> is a fictional comic character. <br>
    I Like Batman Movies </p>

</body>
</html>
</textarea>
<br>
<button class="btn btn-warning" onclick="myFunction4()"> Copy Text </button>
<br>
<br>
<hr>


</div>
</div>


<div id="section5" class="tab-pane fade">
    <div class="col-sm-8">
	<h4><small>RECENT POSTS</small></h4>
      <hr>
      <h1>HTML</h1>
      <h5><span class="glyphicon glyphicon-time"></span> Posted on July 13, 2019.</h5>
      <h5><span class="label label-danger">Web Development</span></h5><br>
	  
<h3> HTML Text Formatting Elements : </h3>

<div class="table-responsive">
<table class="table table-bordered table-striped table-hover">
<thead>
<th> Tag </th>
<th> Description </th>
</thead>
<tbody>
<tr>
<td> &lt;b&gt;</td>
<td> Defines bold text </td>
</tr>

<tr>
<td> &lt;em&gt;</td>
<td>  Defines emphasized text  </td>
</tr>

<tr>
<td> &lt;i&gt;</td>
<td>  Defines italic text </td>
</tr>

<tr>
<td> &lt;small&gt;</td>
<td>   Defines smaller text </td>
</tr>

<tr>
<td> &lt;strong&gt;</td>
<td>  Defines important text </td>
</tr>

<tr>
<td> &lt;sub&gt;</td>
<td>   Defines subscripted text </td>
</tr>

<tr>
<td> &lt;sup&gt;</td>
<td>  Defines superscripted text  </td>
</tr>

<tr>
<td> &lt;ins&gt;</td>
<td>   Defines inserted text </td>
</tr>

<tr>
<td> &lt;del&gt;</td>
<td>   Defines deleted text </td>
</tr>

<tr>
<td> &lt;mark&gt;</td>
<td>  Defines marked/highlighted text  </td>
</tr>

</tbody>
</table>
</div>


<p class="text-center lead"> Example: </p>
	
	 <textarea id="myInput5" class="form-control minih">
	<html> 
	    <head> 
		     <title> Homepage </title>
	     </head>
	        <body>
			   <p> Hello World! </p>
			   <b>This text is bold</b>
			   <strong>This text is strong</strong>
			   <i>This text is italic</i>
			   <em>This text is emphasized</em>
			   <h2>HTML <small>Small</small> Formatting</h2>
			   <h2>HTML <mark>Marked</mark> Formatting</h2>
			   <p>My favorite color is <del>blue</del> red.</p>
			   <p>My favorite <ins>color</ins> is red.</p>
			   <p>This is <sub>subscripted</sub> text.</p>
			   <p>This is <sup>superscripted</sup> text.</p>
			   
			   
	     </body> 
	</html>
	
	</textarea> <br>
	 <button class="btn btn-warning" onclick="myFunction5()"> Copy Text </button>

<br>
<br>
	
	
<hr>


</div>
</div>


<div id="section6" class="tab-pane fade">
    <div class="col-sm-8">
	<h4><small>RECENT POSTS</small></h4>
      <hr>
      <h1>HTML</h1>
      <h5><span class="glyphicon glyphicon-time"></span> Posted on July 13, 2019.</h5>
      <h5><span class="label label-danger">Web Development</span></h5><br>
	  
<h3> HTML Attributes : </h3>
<br>
<p>Below is an alphabetical list of some attributes often used in HTML. </p>
<br>
<div class="table-responsive">
<table class="table table-bordered table-striped table-hover">
<thead>
<th> Attribute </th>
<th> Description </th>
</thead>
<tbody>
<tr>
<td> alt</td>
<td> Specifies an alternative text for an image, when the image cannot be displayed </td>
</tr>

<tr>
<td> disabled </td>
<td>   Specifies that an input element should be disabled </td>
</tr>

<tr>
<td> href </td>
<td>   Specifies the URL (web address) for a link</td>
</tr>

<tr>
<td> id </td>
<td>  Specifies a unique id for an element  </td>
</tr>

<tr>
<td> src</td>
<td> Specifies the URL (web address) for an image</td>
</tr>

<tr>
<td> style</td>
<td> Specifies an inline CSS style for an element </td>
</tr>

<tr>
<td> title    </td>
<td>   Specifies extra information about an element (displayed as a tool tip) </td>
</tr>

<tr>
<td> height and width  </td>
<td>  Specifies size information for images  </td>
</tr>


<tr>
<td> lang  </td>
<td>  declaring the language  </td>
</tr>

</tbody>
</table>
</div>


<p class="text-center lead"> Example</p>
	
	 <textarea id="myInput6" class="form-control minih">
	<html lang="en-US"> 
	    <head> 
		     <title> Homepage </title>
	     </head>
	        <body>
			<div id="rash" style="color:blue;">
			   <p> Hello World! </p>
			   </div>
			   <div id="rash1">
			   <img src="img/screenshot.png" height="400px" width="400px" class="img-responsive">
			   </div>
			   <div id="rash2">
			   <a href="http://www.google.com" target="_blank"> Click Here </a>
			   <h1> MY FORM </h1>
			   <form>
			  Name: <input type="text" name="name">
			   Account No: <input type="text" name="number" disabled>
			   <button type="submit" value="submit"> Submit </button>
			   </form>
			   </div>
	     </body> 
	</html>
	
	</textarea> <br>
	 <button class="btn btn-warning" onclick="myFunction6()"> Copy Text </button>

<br>
<br>
	
	
<hr>



</div>
</div>


<div id="section7" class="tab-pane fade">
    <div class="col-sm-8">
      <h4><small>RECENT POSTS</small></h4>
      <hr>
      <h1>HTML</h1>
      <h5><span class="glyphicon glyphicon-time"></span> Posted on July 12, 2019.</h5>
      <h5><span class="label label-danger">Web Development</span></h5><br>
	  
<h3> Hyperlinks: </h3>

<p>HTML links are hyperlinks.<br>
<br>
You can click on a link and jump to another document.<br>
<br>

When you move the mouse over a link, the mouse arrow will turn into a little hand.<br>
<br>

<h3> Syntax: </h3><br>
<p class="lead"> <code> &lt;a href="url" &gt; </code>  link text <code>&lt;/a&gt;</code> </p>
<br>

<h3>HTML Links - The target Attribute</h3>

<p>The target attribute specifies where to open the linked document.</p><br>
<p>The target attribute can have one of the following values:</p><br>
<ul>
<li><code>_blank </code>- Opens the linked document in a new window or tab</li>
<li> <code>_self </code>- Opens the linked document in the same window/tab as it was clicked (this is default) </li>
<li> <code> _parent </code>- Opens the linked document in the parent frame </li>
<li> <code>_top </code> - Opens the linked document in the full body of the window </li>
<li> <code>framename </code> - Opens the linked document in a named frame</li>
</ul>

<br>


<h3> Summary:</h3>
<ul>
<li>Use the <code>&lt;a&gt;</code> element to define a link </li>
<li>Use the <code>href </code> attribute to define the link address   </li>
<li>Use the <code>target </code> attribute to define where to open the linked document </li>
<li>Use the <code>&lt;img&gt; </code>element (inside <code>&lt;a&gt;</code>) to use an image as a link </li>
<li>Use the <code>id </code> attribute (id="value") to define bookmarks in a page </li>
<li>Use the <code>href </code>attribute (href="#value") to link to the bookmark </li>
</ul>
<br>
<br>



<p class="text-center lead"> Example: </p>
	
	 <textarea id="myInput7" class="form-control minih">
	<html> 
	    <head> 
		     <title> Homepage </title>
	     </head>
	        <body>
			<div id="rash">
			   <p> Hello World! </p>
			   </div>
			   <div id="rash1">
			   <a href="http://www.google.com" target="_blank"> Click Here</a>
			   </div>
			   <div id="rash3" >
			   <a href="url" target="_blank">
			   <img src="lion.jpg"> 
			   </a>
			   <div class="rash4">
			   <a href="#rash"> Jump to hello word </a>
			   </div>
			   
	     </body> 
	</html>
	
	</textarea> <br>
	 <button class="btn btn-warning" onclick="myFunction7()"> Copy Text </button>

<br>
<br>
	
	
<hr>

</div>
</div>




<!-- Tab-content ending-->
</div>


 <div class="col-sm-2 sidenav">
      <div class="well">
        <p>ADS</p>
      </div>
      <div class="well">
        <p>ADS</p>
      </div>
    </div>
</div>
</div>
</div>




<?php include'includes/footer.php';  ?>
</div>
<script>
function myFunction() {
  var copyText = document.getElementById("myInput");
  copyText.select();
  document.execCommand("copy");
  alert("Text Copied");
}

function myFunction1() {
  var copyText = document.getElementById("myInput1");
  copyText.select();
  document.execCommand("copy");
  alert("Text Copied ");
}

function myFunction2() {
  var copyText = document.getElementById("myInput2");
  copyText.select();
  document.execCommand("copy");
  alert("Text Copied");
}

function myFunction3() {
  var copyText = document.getElementById("myInput3");
  copyText.select();
  document.execCommand("copy");
  alert("Text Copied");
}

function myFunction4() {
  var copyText = document.getElementById("myInput4");
  copyText.select();
  document.execCommand("copy");
  alert("Text Copied");
}

function myFunction5() {
  var copyText = document.getElementById("myInput5");
  copyText.select();
  document.execCommand("copy");
  alert("Text Copied");
}
function myFunction6() {
  var copyText = document.getElementById("myInput6");
  copyText.select();
  document.execCommand("copy");
  alert("Text Copied");
}
function myFunction7() {
  var copyText = document.getElementById("myInput6");
  copyText.select();
  document.execCommand("copy");
  alert("Text Copied");
}


</script>

</body>
</html>
